package com.fis.bankapplication.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
 
 
public class AccountTest {
 
	Account account = new Account();
 
 
	@Test
	void setAccountNoTest() {
		account.setAccNumber(1);;
		assertEquals(1, account.getAccNumber());
	}
 
 
	@Test
	void setAccountTypeTest() {
		account.setAccType("Savings");
		assertEquals("Savings", account.getAccType());
	}
 
 
}